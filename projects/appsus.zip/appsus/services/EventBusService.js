var bus = new Vue();

export default bus;